# hurricane
Architecture for automatIzation of smart Cities data management
